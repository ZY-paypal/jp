package com.jpmorgon.settlements.settlementsenrichment.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;
import com.jpmorgon.settlements.settlementsenrichment.Model.Transaction;
import com.jpmorgon.settlements.settlementsenrichment.Model.TransactionDTO;
import com.jpmorgon.settlements.settlementsenrichment.Repository.TransactionRepository;

@Service
@Transactional
public class TransactionService {
	@Autowired
    private TransactionRepository repo;
	 @Autowired
	private SsiInfoService ssiInfoService;
    public List<Transaction> listAll() {
        return repo.findAll();
    }
    public List<Transaction> getBySsiCode(String ssiCode) {
    	
    	SSI_Info ssi=new SSI_Info();
    	ssi=ssiInfoService.get(ssiCode);
    	
        return repo.findBySSI(ssi);
    }
    public List<TransactionDTO> getByTradeID(Integer tradeID) {
    	List<TransactionDTO> transactionDTOList=new ArrayList();
    	Transaction t= get(tradeID);
    	
    		TransactionDTO temp=new TransactionDTO();
    		temp.setMessageID(t.getMessageID());
    		temp.setAmount(t.getAmount());
    		temp.setCurrency(t.getCurrency());
    		temp.setTradeID(t.getTradeID());
    		temp.setValueDate(t.getValueDate());
    		temp.setSupportInfo(t.getSSI().getSupportInfo());
    		temp.setPayerParty(t.getSSI().getPayerParty());
    		temp.setReceiverParty(t.getSSI().getReceiverParty());
    		
    		transactionDTOList.add(temp);
    	return transactionDTOList;
    	
    }
    public List<TransactionDTO> listAllDTO() {
    	List<TransactionDTO> transactionDTOList=new ArrayList();
    	List<Transaction> transactionList=repo.findAll();
    	
    	for(Transaction t:transactionList)
    	{
    		TransactionDTO temp=new TransactionDTO();
    		temp.setMessageID(t.getMessageID());
    		temp.setAmount(t.getAmount());
    		temp.setCurrency(t.getCurrency());
    		temp.setTradeID(t.getTradeID());
    		temp.setValueDate(t.getValueDate());
    		temp.setSupportInfo(t.getSSI().getSupportInfo());
    		temp.setPayerParty(t.getSSI().getPayerParty());
    		temp.setReceiverParty(t.getSSI().getReceiverParty());
    		
    		transactionDTOList.add(temp);
    	}
    	return transactionDTOList;
    	
    }
    public void save(TransactionDTO transactionDTO) {
    	Transaction transaction=new Transaction();
    	SSI_Info ssi=new SSI_Info();
    	String ssiCode=transactionDTO.getSsiCode();
    	try {
    		UUID uuid = UUID.randomUUID();
    		ssi=ssiInfoService.get(ssiCode);
    		ssi.setSsiCode(ssiCode);
    		transaction.setAmount(transactionDTO.getAmount());
        	transaction.setCurrency(transactionDTO.getCurrency());
        	transaction.setTradeID(transactionDTO.getTradeID());
        	transaction.setValueDate(transactionDTO.getValueDate());
        	transaction.setMessageID(uuid.toString());
        	transaction.setSSI(ssi);
            repo.save(transaction);
    	}catch(Exception e)
    	{
    		
    	}
    }
    public void update(Integer tradeID,TransactionDTO transactionDTO) {
    	Transaction transaction=new Transaction();
    	SSI_Info ssi=new SSI_Info();
    	String ssiCode=transactionDTO.getSsiCode();
    
    	try {
    		UUID uuid = UUID.randomUUID();
    		transaction=get(tradeID);
    		ssi=ssiInfoService.get(ssiCode);
    		ssi.setSsiCode(ssiCode);
    		transaction.setAmount(transactionDTO.getAmount());
    		transaction.setCurrency(transactionDTO.getCurrency());
    		transaction.setMessageID(uuid.toString());
    		transaction.setValueDate(transactionDTO.getValueDate());
        	transaction.setSSI(ssi);
            repo.save(transaction);
    	}catch(Exception e)
    	{
    		
    	}
    }
    public Transaction get(Integer tradeID) {
        return repo.findById(tradeID).get();
    }
     
    public void delete(Integer tradeID) {
    	
        repo.deleteById(tradeID);
    }
}
