package com.jpmorgon.settlements.settlementsenrichment.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgon.settlements.settlementsenrichment.Model.Client;
import com.jpmorgon.settlements.settlementsenrichment.Model.ResponseMessage;
import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;
import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_InfoDTO;
import com.jpmorgon.settlements.settlementsenrichment.Model.Transaction;
import com.jpmorgon.settlements.settlementsenrichment.Repository.ClientRepository;
import com.jpmorgon.settlements.settlementsenrichment.Repository.SsiInfoRepository;
import com.jpmorgon.settlements.settlementsenrichment.Repository.TransactionRepository;

@Service
@Transactional
public class SsiInfoService {
	@Autowired
    private SsiInfoRepository repo;
	@Autowired
	  private ClientService clientRepo;
	
	@Autowired
    private TransactionService transactionRepo;
    public List<SSI_Info> listAll() {
        return repo.findAll();
    }
     
    public void  save(SSI_InfoDTO ssi_InfoDTO) {
    	SSI_Info ssiInfo=new SSI_Info();
    	Client payer=new Client();
    	Client receiver=new Client();
    	try {
    		payer=clientRepo.get(ssi_InfoDTO.getPayerPartyID());
    		receiver=clientRepo.get(ssi_InfoDTO.getReceiverPartyID());
    		ssiInfo.setPayerParty(payer);
    		ssiInfo.setReceiverParty(receiver);
    		ssiInfo.setSsiCode(ssi_InfoDTO.getSsiCode());
    		ssiInfo.setSupportInfo(ssi_InfoDTO.getSupportInfo());
            repo.save(ssiInfo);
    	}catch(Exception e)
    	{
    		
    	}
    
      
    }
     
    public SSI_Info get(String ssiCode) {
        return repo.findById(ssiCode).get();
    }
     
    public ResponseMessage delete(String ssiCode) {
    	List<Transaction> transaction=new ArrayList();
    	try {
    		transaction=transactionRepo.getBySsiCode(ssiCode);
    		if(transaction!=null&&transaction.size()>0)
    		{
    			return new ResponseMessage("Unsuccess", "Delete Unsuccessful. "+transaction.size()+" Transaction using this SSI Code");
    		}else
    		{
    			 repo.deleteById(ssiCode);
    			
    		}
    	}catch(Exception e)
    	{
    		
    	}
    	 return new ResponseMessage("Success", "Delete Successful");
    }
}
