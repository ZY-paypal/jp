package com.jpmorgon.settlements.settlementsenrichment.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpmorgon.settlements.settlementsenrichment.Model.Client;
import com.jpmorgon.settlements.settlementsenrichment.Model.ResponseMessage;
import com.jpmorgon.settlements.settlementsenrichment.Service.ClientService;
@RestController
public class ClientController {
	  @Autowired
	  private ClientService service;
	  @CrossOrigin
	  @GetMapping("/getClientList")
	  public List<Client> list() {
	      return service.listAll();
	  }
	  @CrossOrigin
	  @GetMapping("/getClientByID/{id}")
	    public Client getSSIByID(@PathVariable Integer id){
	        return service.get(id);
	    }
	  @CrossOrigin
	    @PostMapping("/CreateClient")
	    public ResponseMessage create(@RequestBody Client body){
	        service.save(body);
	        return new ResponseMessage("Success","Create Successful");
	    }

//	    @PutMapping("/UpdateSSI/{id}")
//	    public ResponseMessage update(@PathVariable String SsiCode, @RequestBody SSI_Info body){
//	      
//	        // getting blog
//	    	SSI_Info ssi = service.get(SsiCode);
//	    	ssi.setPayerAccountNumber(body.getPayerAccountNumber());
//	    	ssi.setPayerBank(body.getPayerBank());
//	    	ssi.setReceiverAccountNumber(body.getPayerAccountNumber());
//	    	ssi.setReceiverBank(body.getReceiverBank());
//	    	ssi.setSupportInfo(body.getSupportInfo());
//	        service.save(ssi);
//	        
//	        return new ResponseMessage("Success","Update Successful");
//	    }
	  @CrossOrigin
	    @DeleteMapping("DeleteClient/{id}")
	    public boolean delete(@PathVariable Integer id){

	    	service.delete(id);
	        return true;
	    }
}
