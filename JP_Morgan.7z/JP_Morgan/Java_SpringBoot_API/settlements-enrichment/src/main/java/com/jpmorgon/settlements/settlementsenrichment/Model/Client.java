package com.jpmorgon.settlements.settlementsenrichment.Model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="client")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Client {
	@Id
	@Column(nullable = false,name="Client_ID")
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer clientID;
	@Column(nullable = false,name="Account_Number")
    private String AccountNumber;
	@Column(nullable = false,name="Bank")
    private String BankCode;
//	@OneToMany(mappedBy = "PayerParty",fetch=FetchType.LAZY)
//	@JsonBackReference
   // private SSI_Info PayerSsiInfo;
//	@OneToMany(mappedBy = "ReceiverParty",fetch=FetchType.LAZY)
//	@JsonBackReference
  //  private SSI_Info ReceiverSsiInfo;
	
	
	
//	public SSI_Info getPayerSsiInfo() {
//		return PayerSsiInfo;
//	}
//	public void setPayerSsiInfo(SSI_Info payerSsiInfo) {
//		PayerSsiInfo = payerSsiInfo;
//	}
//	public SSI_Info getReceiverSsiInfo() {
//		return ReceiverSsiInfo;
//	}
//	public void setReceiverSsiInfo(SSI_Info receiverSsiInfo) {
//		ReceiverSsiInfo = receiverSsiInfo;
//	}
	public Client()
    {
    	
    }
    public Client(Integer ClientID,String AccountNumber,String Bank)
    {
    	this.clientID=ClientID;
    	this.AccountNumber=AccountNumber;
    	this.BankCode= Bank;
    }
  
	
	public Integer getClientID() {
		return clientID;
	}
	public void setClientID(Integer clientID) {
		this.clientID = clientID;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getBankCode() {
		return BankCode;
	}
	public void setBankCode(String bank) {
		BankCode = bank;
	}
    
}
