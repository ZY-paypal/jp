package com.jpmorgon.settlements.settlementsenrichment.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpmorgon.settlements.settlementsenrichment.Model.ResponseMessage;
import com.jpmorgon.settlements.settlementsenrichment.Model.Transaction;
import com.jpmorgon.settlements.settlementsenrichment.Model.TransactionDTO;
import com.jpmorgon.settlements.settlementsenrichment.Service.TransactionService;

@RestController
public class TransactionController {
	@Autowired
	private TransactionService service;

//	  @GetMapping("/getTransactionList")
//	  public List<Transaction> list() {
//	      return service.listAll();
//	  }
	@CrossOrigin
	@GetMapping("/getTransactionList")
	@ResponseBody
	public List<TransactionDTO> getTransactions() {
		return service.listAllDTO();
	}
	@CrossOrigin
	@GetMapping("/getTransactionByTradeID/{tradeID}")
	public List<TransactionDTO> getClientByID(@PathVariable Integer tradeID) {
		return service.getByTradeID(tradeID);
	}
	@CrossOrigin
	@PostMapping(value = "/CreateTransaction", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseMessage create(@RequestBody TransactionDTO body) {

		service.save(body);
		return new ResponseMessage("Success", "Create Successful");
	}
	@CrossOrigin
	@PutMapping("/UpdateTransaction/{tradeID}")
	public ResponseMessage update(@PathVariable Integer tradeID, @RequestBody TransactionDTO body) {

		service.update(tradeID,body);

		return new ResponseMessage("Success", "Update Successful");
	}
	@CrossOrigin
	@DeleteMapping("DeleteTransaction/{tradeID}")
	public ResponseMessage delete(@PathVariable Integer tradeID) {

		service.delete(tradeID);
		return new ResponseMessage("Success", "Delete Successful");
	}
}
