package com.jpmorgon.settlements.settlementsenrichment.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jpmorgon.settlements.settlementsenrichment.Model.Client;
import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;


public interface ClientRepository  extends JpaRepository<Client, Integer> {
	Client findByClientID(Integer ClientID);
}

