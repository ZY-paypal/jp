package com.jpmorgon.settlements.settlementsenrichment.Model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.swing.text.View;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name = "transaction")
public class Transaction {
	@Id
	@Column(nullable = false,name="Trade_ID")
	private Integer TradeID;
	@Column(nullable = false,name="Message_ID")
    private String MessageID;
	@Column(nullable = false,name="Amount")
    private double Amount;
	@Column(nullable = false,name="Currency")
    private String Currency;
	@Column(nullable = false,name="Value_Date")
    private String ValueDate;
	@ManyToOne(cascade = {CascadeType.DETACH, CascadeType.REFRESH},fetch=FetchType.LAZY)
    @JoinColumn(name = "SSI_Code", referencedColumnName = "SSI_Code")
    private SSI_Info SSI;
    
    public Transaction()
    {
    	
    }
    public Transaction(Integer TradeID,String MessageID,double Amount,String Currency,String ValueDate,SSI_Info SSI)
    {
    	this.TradeID=TradeID;
    	this.MessageID=MessageID;
    	this.Amount=Amount;
    	this.Currency=Currency;
    	this.ValueDate=ValueDate;
    	this.SSI=SSI;
    }
    
    
	public Integer getTradeID() {
		return TradeID;
	}
	public void setTradeID(Integer tradeID) {
		TradeID = tradeID;
	}
	public String getMessageID() {
		return MessageID;
	}
	public void setMessageID(String messageID) {
		MessageID = messageID;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getValueDate() {
		return ValueDate;
	}
	public void setValueDate(String valueDate) {
		ValueDate = valueDate;
	}
	
	public SSI_Info getSSI() {
		return SSI;
	}
	public void setSSI(SSI_Info sSI) {
		SSI = sSI;
	}


    
    
}
