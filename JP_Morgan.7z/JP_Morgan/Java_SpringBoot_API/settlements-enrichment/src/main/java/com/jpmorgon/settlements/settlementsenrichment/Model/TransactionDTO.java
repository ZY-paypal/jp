package com.jpmorgon.settlements.settlementsenrichment.Model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "tradeID", "messageID" , "amount" , "currency" , "valueDate" , "payerParty", "receiverParty", "supportInfo" })
public class TransactionDTO {
	
	private Integer tradeID;
    private String messageID;
    private double amount;
    private String currency;
    private String valueDate;
    private String ssiCode;
    private Client payerParty;
    private Client receiverParty;
    private String supportInfo;
	public Integer getTradeID() {
		return tradeID;
	}
	public void setTradeID(Integer tradeID) {
		this.tradeID = tradeID;
	}
	public String getMessageID() {
		return messageID;
	}
	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getValueDate() {
		return valueDate;
	}
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
	public Client getPayerParty() {
		return payerParty;
	}
	public void setPayerParty(Client payerParty) {
		this.payerParty = payerParty;
	}
	public Client getReceiverParty() {
		return receiverParty;
	}
	public void setReceiverParty(Client receiverParty) {
		this.receiverParty = receiverParty;
	}
	public String getSupportInfo() {
		return supportInfo;
	}
	public void setSupportInfo(String supportInfo) {
		this.supportInfo = supportInfo;
	}
	public String getSsiCode() {
		return ssiCode;
	}
	public void setSsiCode(String ssiCode) {
		this.ssiCode = ssiCode;
	}
	public TransactionDTO(Integer tradeID, String messageID, double amount, String currency, String valueDate,
			String ssiCode, Client payerParty, Client receiverParty, String supportInfo) {
		
		this.tradeID = tradeID;
		this.messageID = messageID;
		this.amount = amount;
		this.currency = currency;
		this.valueDate = valueDate;
		this.ssiCode = ssiCode;
		this.payerParty = payerParty;
		this.receiverParty = receiverParty;
		this.supportInfo = supportInfo;
	}
	public TransactionDTO()
	{
		
	}
    
    
    
}
