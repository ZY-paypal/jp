package com.jpmorgon.settlements.settlementsenrichment.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpmorgon.settlements.settlementsenrichment.Model.ResponseMessage;
import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;
import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_InfoDTO;
import com.jpmorgon.settlements.settlementsenrichment.Service.SsiInfoService;

@RestController
public class SsiInfoController {
	@Autowired
	private SsiInfoService service;
	@CrossOrigin
	@GetMapping("/getSsiList")
	public List<SSI_Info> list() {
		return service.listAll();
	}
	@CrossOrigin
	@GetMapping("/getSSIByID/{id}")
	public SSI_Info getSSIByID(@PathVariable String id) {
		return service.get(id);
	}
	@CrossOrigin
	@PostMapping("/CreateSSI")
	public ResponseMessage create(@RequestBody SSI_InfoDTO body) {
		service.save(body);
		return new ResponseMessage("Success", "Create Successful");
	}

//	    @PutMapping("/UpdateSSI/{id}")
//	    public ResponseMessage update(@PathVariable String SsiCode, @RequestBody SSI_Info body){
//	      
//	        // getting blog
//	    	SSI_Info ssi = service.get(SsiCode);
//	    	ssi.setPayerAccountNumber(body.getPayerAccountNumber());
//	    	ssi.setPayerBank(body.getPayerBank());
//	    	ssi.setReceiverAccountNumber(body.getPayerAccountNumber());
//	    	ssi.setReceiverBank(body.getReceiverBank());
//	    	ssi.setSupportInfo(body.getSupportInfo());
//	        service.save(ssi);
//	        
//	        return new ResponseMessage("Success","Update Successful");
//	    }
	@CrossOrigin
	@DeleteMapping("DeleteSSI/{SsiCode}")
	public ResponseMessage delete(@PathVariable String SsiCode) {

		return service.delete(SsiCode);
	}
}
