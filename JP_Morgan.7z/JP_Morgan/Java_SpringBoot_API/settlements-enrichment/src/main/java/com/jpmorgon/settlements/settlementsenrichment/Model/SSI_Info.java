package com.jpmorgon.settlements.settlementsenrichment.Model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="ssi")
public class SSI_Info {
	@Id
	@Column(nullable = false,name="SSI_CODE")
	private String ssiCode;
	
	@Column(nullable = true,name="Supporting_Information")
    private String SupportInfo;
	
	@OneToMany(mappedBy = "SSI",cascade = {CascadeType.DETACH, CascadeType.REFRESH})
	@JsonBackReference
    private List<Transaction> transaction;
	@OneToOne(cascade = {CascadeType.DETACH, CascadeType.REFRESH},fetch=FetchType.LAZY)
    @JoinColumn(name = "Payer_ID")
    private Client PayerParty;
	@OneToOne(cascade = {CascadeType.DETACH, CascadeType.REFRESH},fetch=FetchType.LAZY)
    @JoinColumn(name = "Receiver_ID")
    private Client ReceiverParty;
	
	public SSI_Info()
	{
		
	}
	public Client getPayerParty() {
		return PayerParty;
	}
	public void setPayerParty(Client payerParty) {
		PayerParty = payerParty;
	}
	public Client getReceiverParty() {
		return ReceiverParty;
	}
	public void setReceiverParty(Client receiverParty) {
		ReceiverParty = receiverParty;
	}
//	@JsonIgnore
//	public Transaction getTransaction() {
//		return transaction;
//	}
//	@JsonIgnore
//	public void setTransaction(Transaction transaction) {
//		this.transaction = transaction;
//	}
	
	public SSI_Info(String SsiCode,String SupportInfo,Client PayerParty,Client ReceiverParty)
	{
		this.ssiCode=SsiCode;
    	this.SupportInfo=SupportInfo;
    	this.PayerParty=PayerParty;
    	this.ReceiverParty=ReceiverParty;
	}
	
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	public String getSsiCode() {
		return ssiCode;
	}

	public void setSsiCode(String SsiCode) {
		ssiCode = SsiCode;
	}

	public String getSupportInfo() {
		return SupportInfo;
	}

	public void setSupportInfo(String supportInfo) {
		SupportInfo = supportInfo;
	}
	
	
	
}
