package com.jpmorgon.settlements.settlementsenrichment.Model;

import javax.persistence.Column;

public class SSI_InfoDTO {
	private String ssiCode;
    private String supportInfo;
    private Integer payerPartyID;
    private Integer receiverPartyID;
    
    public SSI_InfoDTO()
    {
    	
    }
    
	public SSI_InfoDTO(String ssiCode, String supportInfo, Integer payerPartyID, Integer receiverPartyID) {
		
		this.ssiCode = ssiCode;
		this.supportInfo = supportInfo;
		this.payerPartyID = payerPartyID;
		this.receiverPartyID = receiverPartyID;
	}

	public Integer getPayerPartyID() {
		return payerPartyID;
	}

	public void setPayerPartyID(Integer payerPartyID) {
		this.payerPartyID = payerPartyID;
	}

	public Integer getReceiverPartyID() {
		return receiverPartyID;
	}

	public void setReceiverPartyID(Integer receiverPartyID) {
		this.receiverPartyID = receiverPartyID;
	}

	public String getSsiCode() {
		return ssiCode;
	}
	public void setSsiCode(String ssiCode) {
		this.ssiCode = ssiCode;
	}
	public String getSupportInfo() {
		return supportInfo;
	}
	public void setSupportInfo(String supportInfo) {
		this.supportInfo = supportInfo;
	}
	
    
    
    
    
    
}
