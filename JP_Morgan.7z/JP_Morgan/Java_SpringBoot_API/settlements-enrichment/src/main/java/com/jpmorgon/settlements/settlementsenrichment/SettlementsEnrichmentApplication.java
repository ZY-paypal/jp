package com.jpmorgon.settlements.settlementsenrichment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SettlementsEnrichmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SettlementsEnrichmentApplication.class, args);

	}

}
