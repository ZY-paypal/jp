package com.jpmorgon.settlements.settlementsenrichment;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.jpmorgon.settlements.settlementsenrichment.Controller.TransactionController;
import com.jpmorgon.settlements.settlementsenrichment.Model.Client;
import com.jpmorgon.settlements.settlementsenrichment.Model.TransactionDTO;
import com.jpmorgon.settlements.settlementsenrichment.Service.TransactionService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = TransactionController.class)
@WithMockUser
public class TransactionControllerTest {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private TransactionService transactionService;
	

}
