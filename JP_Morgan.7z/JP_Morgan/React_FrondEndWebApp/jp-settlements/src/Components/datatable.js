import React, { Component } from 'react'
import DataTable from 'react-data-table-component';
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import memoize from 'memoize-one';
import TextField from '@material-ui/core/TextField';

import SimpleModal from './customModal';
const CustomTitle = ({ row }) => (
  <div>
    {}
 
    <div>
      <div style={{  overflow: 'hidden', whiteSpace: 'wrap', textOverflow: 'ellipses',textAlign:'left' }}>
        {}
        {row.messageID}
      </div>
    </div>
  </div>
);
const columns = memoize(deleteHandler => [
  {
    name: 'Trade ID',
    selector: 'tradeID',
    sortable: true,
  },
  {
    name: 'Message ID',
    selector: 'messageID',
    sortable: true,
    maxWidth: '500px', 
    cell: row => <CustomTitle row={row} />
  },
  {
    name: 'Amout',
    selector: 'amount',
    sortable: true
  },
  {
    name: 'Currency',
    selector: 'currency',
    sortable: true
  },
  {
    name: 'Value Date',
    selector: 'valueDate',
    sortable: true
  },
  {
    name: 'Payer Account Number',
    selector: 'payerParty.accountNumber',
    sortable: true
  },
  {
    name: 'Payer Bank',
    selector: 'payerParty.bankCode',
    sortable: true
  },
  {
    name: 'Receiver Account Number',
    selector: 'receiverParty.accountNumber',
    sortable: true
  },
  {
    name: 'Receiver Account Number',
    selector: 'receiverParty.bankCode',
    sortable: true
  },
  {
    name: 'Supporting Info',
    selector: 'supportInfo',
    sortable: true
  },
  {
    cell: row => <ActionComponent row={row} onClick={deleteHandler} >Delete</ActionComponent>,
    button: true,
  }
]);
const handleRowClicked = row => {

  console.log(`${row.tradeID} was clicked!`);
}
const ActionComponent = ({ row, onClick }) => {
  const deleteHandler = () => onClick(row);

  return <Button variant="contained" onClick={deleteHandler} color="secondary">Delete</Button>;
};

const sortIcon = <ArrowDownward />;

class BasicTable extends Component {
  constructor() {
    super();
    this.RefreshRecords = this.RefreshRecords.bind(this);
    this.state = { tradeIdFromDatatable: '' };
}
handleChange = ({ target }) => {
  this.setState({ tradeIdFromDatatable: target.value });
};
btnSearchClicked = event => {
  
  this.props.FetchRecord(this.state.tradeIdFromDatatable);
};
btnGetAllClicked = event => {
  this.setState({ tradeIdFromDatatable: "" });
  this.props.FetchRecord("");
};

RefreshRecords()
{
  this.props.FetchRecord("");
}
  deleteOne = row => {

    if (window.confirm(`Are you sure you want to delete:\r ${row.tradeID}?`)) {

      const requestOptions = {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      };
      fetch(window.$host+'/DeleteTransaction/' + row.tradeID, requestOptions)
        .then(async response => {
          const data = await response.json();

          // check for error response
          if (!response.ok) {
            // get error message from body or default to response status
            const error = (data && data.message) || response.status;
            return Promise.reject(error);
          } else {
            //delete record from UI
            const index = this.props.transactions.findIndex(r => r === row);
            this.props.FetchRecord("");
          }

        }).then(result => console.log(result))
        .catch(error => {
          
          console.error('There was an error!', error);
        });
    }
  }
  render() {
    return (

      <Card style={{ height: '100%' }}>
       
        <SimpleModal props={this.props} ssiList={this.props.ssiList} RefreshRecords={this.RefreshRecords}/> 


        <DataTable

          columns={columns(this.deleteOne)}
          data={this.props.transactions}
          highlightOnHover
          striped
          sortIcon={sortIcon}
          onSelectedRowsChange={this.handleChange}
          onRowClicked={handleRowClicked}
          pagination
          subHeader={true}
          subHeaderComponent={
            (
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <TextField id="outlined-basic" label="Search by Trade ID"  value={this.state.tradeIdFromDatatable}  onChange={this.handleChange} variant="outlined" size="small" style={{ margin: '5px'}} />
                <Button  color="primary" variant="contained" onClick={this.btnSearchClicked} style={{ margin: '5px',marginRight:'20px' }}>
                  Search
                </Button>
                <Button  color="primary" variant="contained" onClick={this.btnGetAllClicked} style={{ margin: '5px',marginRight:'20px' }}>
                  Retrieve All
                </Button>
              </div>
            )
          }
        />

      </Card>
    );
  }
}

export default BasicTable;