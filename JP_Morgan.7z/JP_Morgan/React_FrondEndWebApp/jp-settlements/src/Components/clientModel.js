import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';



export default function FormDialog(props)   {
  const [open, setOpen] = React.useState(false);
  const [accountNumber, setAccountNumber] = React.useState('');
  const [bankCode, setBankCode] = React.useState('');
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const handleClick = () => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        accountNumber: accountNumber,
        bankCode: bankCode
        })
  };
  fetch(window.$host+'/CreateClient', requestOptions)
      .then(async response => {
          const data = await response.json();

          // check for error response
          if (!response.ok) {
              // get error message from body or default to response status
              const error = (data && data.message) || response.status;
              return Promise.reject(error);
          }else{
            props.RefreshRecords();
            setOpen(false);
          }

      })
      .catch(error => {
        
          console.error('There was an error!', error);
      });
  };
 
  return (
    <div style={{ textAlign: 'end', marginRight: '50px' }}>
      <Button variant="contained"  style={{ marginTop: '20px' }} color="primary" onClick={handleClickOpen}>
      Add Client
      </Button>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">Client</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="accountNumber"
            label="Account Number"
            fullWidth
            onChange={(event) => {setAccountNumber(event.target.value)}}
          />

        <TextField
            margin="dense"
            id="bankCode"
            label="Bank Code"
            fullWidth
            onChange={(event) => {setBankCode(event.target.value)}}
            style={{ marginTop: '20px' }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClick} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}