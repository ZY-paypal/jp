import React, { Component } from 'react'
import DataTable from 'react-data-table-component';
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import ArrowDownward from '@material-ui/icons/ArrowDownward';
import memoize from 'memoize-one';
import ClientModal from './clientModel';
import SsiModal from './ssiModel';
const columns = memoize(deleteHandler => [
  {
    name: 'SSI CODE',
    selector: 'ssiCode',
    sortable: true,
  },
  {
    name: 'Payer ID',
    selector: 'payerParty.clientID',
    sortable: true,
  },
  {
    name: 'Payer Account Number',
    selector: 'payerParty.accountNumber',
    sortable: true,
  },
  {
    name: 'Payer Bank Code',
    selector: 'payerParty.bankCode',
    sortable: true,
  },
  {
    name: 'Receiver ID',
    selector: 'receiverParty.clientID',
    sortable: true
  },
  {
    name: 'Receiver Account Number',
    selector: 'receiverParty.accountNumber',
    sortable: true,
  },
  {
    name: 'Receiver Bank Code',
    selector: 'receiverParty.bankCode',
    sortable: true,
  },
  {
    name: 'Supporting Info',
    selector: 'supportInfo',
    sortable: true
  },
  {
    cell: row => <ActionComponent row={row} onClick={deleteHandler} >Delete</ActionComponent>,
    button: true,
  }
]);
const ActionComponent = ({ row, onClick }) => {
  const deleteHandler = () => onClick(row);

  return <Button variant="contained" onClick={deleteHandler} color="secondary">Delete</Button>;
};
const sortIcon = <ArrowDownward />;
class ssi extends React.Component {
    constructor() {
        super();
        this.RefreshRecords = this.RefreshRecords.bind(this);
    }
    RefreshRecords()
    {
      this.props.FetchSSIRecord();
      this.props.FetchClientRecord();
    }
      deleteOne = row => {
    
        if (window.confirm(`Are you sure you want to delete:\r ${row.ssiCode}?`)) {
    
          const requestOptions = {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
          };
          fetch(window.$host+'/DeleteSSI/' + row.ssiCode, requestOptions)
            .then(async response => {
              const data = await response.json();
    
              // check for error response
              if (!response.ok) {
                // get error message from body or default to response status
                const error = (data && data.message) || response.status;
                return Promise.reject(error);
              } else {
                  if(data.statusCode=="Success")
                  {
                    //delete record from UI
                    const index = this.props.ssiList.findIndex(r => r === row);
                    this.props.FetchSSIRecord();
                  }else{
                         alert(data.message);
                  }
                
              }
            }).then(result => console.log(result))
            .catch(error => {
             
              console.error('There was an error!', error);
            });
        }
      }
      render() {
        return (
    
          <Card style={{ height: '100%' }}>
           <ClientModal props={this.props} RefreshRecords={this.RefreshRecords}/> 
            <SsiModal props={this.props} clientList={this.props.clientList} RefreshRecords={this.RefreshRecords}/> 
            <DataTable
    
              columns={columns(this.deleteOne)}
              data={this.props.ssiList}
              highlightOnHover
              striped
              sortIcon={sortIcon}
              onSelectedRowsChange={this.handleChange}
              pagination
            />
    
          </Card>
        );
      }
      
    }
  export default ssi;