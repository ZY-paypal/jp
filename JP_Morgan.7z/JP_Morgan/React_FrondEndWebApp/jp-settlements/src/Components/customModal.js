import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
export default function FormDialog(props) {
  const [open, setOpen] = React.useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setSsiCode("");
    setOpen(false);
  };
  const [tradeID, setTradeID] = React.useState('');
  const [ssiCode, setSsiCode] = React.useState('');
  const [amount, setAmount] = React.useState('');
  const [currency, setCurrency] = React.useState('');
  const [valueDate, setValueDate] = React.useState('');
  const [PayerSelectOpen, setSSISelectOpen] = React.useState(false);
  const handleSSISelectClose = () => {
    setSSISelectOpen(false);
  };
  const handleChange = event => {
    setSsiCode(event.target.value);
  };
  const handleSSISelectOpen = () => {
    setSSISelectOpen(true);
  };
  const handleClick = () => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tradeID: tradeID,
        amount: amount,
        currency: currency,
        valueDate: valueDate,
        ssiCode: ssiCode

      })
    };
    fetch(window.$host+'/CreateTransaction', requestOptions)
      .then(async response => {
        const data = await response.json();

        // check for error response
        if (!response.ok) {
          // get error message from body or default to response status
          const error = (data && data.message) || response.status;
          return Promise.reject(error);
        } else {
          props.RefreshRecords();
          setOpen(false);
        }

      })
      .catch(error => {

        console.error('There was an error!', error);
      });
  };
  return (
    <div style={{ textAlign: 'end', marginRight: '50px' }}>
      <Button variant="contained" style={{ marginTop: '20px' }} color="primary" onClick={handleClickOpen}>
        Add transaction
      </Button>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">Transaction</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="tradeID"
            label="Trade ID"
            type="number"
            fullWidth
            onChange={(event) => { setTradeID(event.target.value) }}
            style={{ marginTop: '20px' }}
          />

          <InputLabel id="demo-simple-select-helper-label" style={{ marginTop: '20px' }}>SSI Code</InputLabel>
          <Select
            labelId="demo-simple-select-helper-label"
            fullWidth
            value={ssiCode}
            onChange={handleChange}
            inputProps={{
              id: "open-select"
            }}
            onClose={handleSSISelectClose}
            onOpen={handleSSISelectOpen}
          >
            {props.ssiList.map((option, key) => (
              <MenuItem value={option.ssiCode} key={key}>
                {option.ssiCode}
              </MenuItem>
            ))}
          </Select>
          <TextField

            margin="dense"
            id="amount"
            label="Amount"
            fullWidth
            onChange={(event) => { setAmount(event.target.value) }}
            style={{ marginTop: '20px' }}
          />
          <TextField

            margin="dense"
            id="currency"
            label="Currency"
            fullWidth
            onChange={(event) => { setCurrency(event.target.value) }}
            style={{ marginTop: '20px' }}
          />
          <TextField

            margin="dense"
            id="valueDate"
            label="Value Date"
            type="number"
            fullWidth
            onChange={(event) => { setValueDate(event.target.value) }}
            style={{ marginTop: '20px' }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClick} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}