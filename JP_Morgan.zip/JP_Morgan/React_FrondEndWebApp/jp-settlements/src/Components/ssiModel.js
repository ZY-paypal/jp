import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';



export default function FormDialog(props)   {
  const [open, setOpen] = React.useState(false);
  const [PayerSelectOpen, setPayerSelectOpen] = React.useState(false);
  const [ReceiverSelectOpen, setReceiverSelectOpen] = React.useState(false);
  const [ssiCode, setCode] = React.useState('');
  const [supportingInfo, setSupportInfo] = React.useState('');
  const [payerID, setPayerID] = React.useState('');
  const [receiverID, setReceiverID] = React.useState('');
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setPayerID("");
    setReceiverID("");
    setOpen(false);
  };
  const handlePayerSelectClose = () => {
    setPayerSelectOpen(false);
  };

  const handlePayerSelectOpen = () => {
    setPayerSelectOpen(true);
  };
  const handleReceiverSelectClose = () => {
    setReceiverSelectOpen(false);
  };

  const handleReceiverSelectOpen = () => {
    setReceiverSelectOpen(true);
  };
  const handleChange = event => {
    setPayerID(event.target.value);
  };
  const handleReceiverChange = event => {
    setReceiverID(event.target.value);
  };
  const handleClick = () => {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ssiCode: ssiCode,
        payerPartyID: payerID,
        receiverPartyID: receiverID,
        supportInfo:supportingInfo
        })
  };
  fetch(window.$host+'/CreateSSI', requestOptions)
      .then(async response => {
          const data = await response.json();

          // check for error response
          if (!response.ok) {
              // get error message from body or default to response status
              const error = (data && data.message) || response.status;
              return Promise.reject(error);
          }else{
            props.RefreshRecords();
            setOpen(false);
          }

      })
      .catch(error => {
        
          console.error('There was an error!', error);
      });
  };
 
  return (
    <div style={{ textAlign: 'end', marginRight: '50px' }}>
      <Button variant="contained"  style={{ marginTop: '20px' }} color="primary" onClick={handleClickOpen}>
      Add SSI
      </Button>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">SSI</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="ssiCode"
            label="SSI Code"
            fullWidth
            onChange={(event) => {setCode(event.target.value)}}
          />
            <InputLabel id="demo-simple-select-helper-label"  style={{ marginTop: '20px' }}>Payer ID (Bank:AccountNumber)</InputLabel>
          <Select
          labelId="demo-simple-select-helper-label"
          fullWidth
         
          value={payerID}
          onChange={handleChange}
          inputProps={{
            id: "open-select"
          }}
          onClose={handlePayerSelectClose}
          onOpen={handlePayerSelectOpen}
        >
           {props.clientList.map((option, key) => (
            <MenuItem value={option.clientID} key={key}>
              {option.clientID} ({option.bankCode}:{option.accountNumber})
            </MenuItem>
          ))}
        </Select>
        <InputLabel id="demo-simple-select-helper-label"  style={{ marginTop: '20px' }}>Receiver ID (Bank:AccountNumber)</InputLabel>
          <Select
          labelId="demo-simple-select-helper-label"
          fullWidth
          value={receiverID}
          onChange={handleReceiverChange}
          inputProps={{
            id: "open-select"
          }}
          onClose={handleReceiverSelectClose}
          onOpen={handleReceiverSelectOpen}
        >
           {props.clientList.map((option, key) => (
            <MenuItem value={option.clientID} key={key}>
              {option.clientID} ({option.bankCode}:{option.accountNumber})
            </MenuItem>
          ))}
        </Select>

        <TextField
            margin="dense"
            id="supportInfo"
            label="Supporting Information"
            fullWidth
            onChange={(event) => {setSupportInfo(event.target.value)}}
            style={{ marginTop: '20px' }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClick} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}