import React, { Component } from 'react';
import './App.css';
import Table from './Components/datatable';
import SSI from './Components/ssi';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    NavLink
} from "react-router-dom";
class App extends Component {
    constructor() {
        super();
        this.RemoveItem = this.RemoveItem.bind(this);
        this.FetchRecord = this.FetchRecord.bind(this);
        this.RemoveSSIItem = this.RemoveSSIItem.bind(this);
        this.FetchSSIRecord = this.FetchSSIRecord.bind(this);
        this.FetchClientRecord = this.FetchClientRecord.bind(this);
    }
    onRouteChanged() {
        console.log("ROUTE CHANGED");
    }

    render() {

        return (
            //<Contacts contacts={this.state.contacts} />
            <div className="App">

                <Router>
                    <div>
                        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">

                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">
                                    <li className="nav-item" style={{ marginRight: "20px" }}>
                                        <NavLink to="/">Transaction</NavLink >
                                    </li>
                                    <li className="nav-item">
                                        <NavLink to="/ssi">SSI</NavLink >
                                    </li>
                                </ul>
                            </div>
                        </nav>
                        <Switch>
                            <Route exact path="/">
                                <Table transactions={this.state.transactions} ssiList={this.state.ssiList} FetchRecord={this.FetchRecord} RemoveItem={this.RemoveItem} />
                            </Route>
                            <Route path="/ssi" >
                                <SSI ssiList={this.state.ssiList} clientList={this.state.clientList} FetchClientRecord={this.FetchClientRecord} FetchSSIRecord={this.FetchSSIRecord} RemoveSSIItem={this.RemoveSSIItem} />
                            </Route>
                        </Switch>
                    </div>
                </Router>


            </div>
        )
    }

    state = {
        transactions: [],
        ssiList: [],
        clientList: []
    };
    RemoveItem(value) {
        this.setState(state => ({
            transactions: [...state.transactions.slice(0, value), ...state.transactions.slice(value + 1)],
        }));
    }
    RemoveSSIItem(value) {
        this.setState(state => ({
            ssiList: [...state.ssiList.slice(0, value), ...state.ssiList.slice(value + 1)],
        }));
    }


    componentDidMount() {
        this.FetchRecord("");
        this.FetchSSIRecord();
        this.FetchClientRecord();
    }
    FetchRecord(tradeID) {

        if(tradeID=="")
        {
            fetch(window.$host+'/getTransactionList')
            .then(res => res.json())
            .then((data) => {
                this.setState({ transactions: data })

            })
            .catch(console.log)
        }else
        {
            fetch(window.$host+'/getTransactionByTradeID/'+tradeID)
            .then(res => res.json())
            .then((data) => {
                this.setState({ transactions: data })

            })
            .catch(console.log)
        }
        
    }
    FetchSSIRecord() {
        fetch(window.$host+'/getSsiList')
            .then(res => res.json())
            .then((data) => {
                this.setState({ ssiList: data })

            })
            .catch(console.log)
    }
    FetchClientRecord() {
        fetch(window.$host+'/getClientList')
            .then(res => res.json())
            .then((data) => {
                this.setState({ clientList: data })

            })
            .catch(console.log)
    }
}
export default App;
