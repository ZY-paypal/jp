package com.jpmorgon.settlements.settlementsenrichment.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;
import com.jpmorgon.settlements.settlementsenrichment.Model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer>{
	

	List<Transaction> findBySSI(SSI_Info SSI_Info);
}
