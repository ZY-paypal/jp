package com.jpmorgon.settlements.settlementsenrichment.Service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmorgon.settlements.settlementsenrichment.Model.Client;
import com.jpmorgon.settlements.settlementsenrichment.Repository.ClientRepository;

@Service
@Transactional
public class ClientService {
	@Autowired
    private ClientRepository repo;
    public List<Client> listAll() {
    	
    	
        return repo.findAll();
    }
 
    public void  save(Client Client) {
        repo.save(Client);
      
    }
     
    public Client get(Integer ClientID) {
        return repo.findById(ClientID).get();
    }
     
    public void delete(Integer ClientID) {
        repo.deleteById(ClientID);
    }
}
