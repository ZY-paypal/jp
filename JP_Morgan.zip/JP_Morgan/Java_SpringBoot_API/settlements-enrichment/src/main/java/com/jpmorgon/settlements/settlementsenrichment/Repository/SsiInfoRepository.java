package com.jpmorgon.settlements.settlementsenrichment.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.jpmorgon.settlements.settlementsenrichment.Model.SSI_Info;

public interface SsiInfoRepository extends JpaRepository<SSI_Info, String> {
	
	SSI_Info findBySsiCode(String SsiCode);
}
