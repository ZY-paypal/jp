package com.jpmorgon.settlements.settlementsenrichment.Model;

public class ResponseMessage {
	private String StatusCode;
	private String Message;
	
	public ResponseMessage()
	{
		
	}
	public ResponseMessage(String StatusCode,String Message)
	{
		this.StatusCode=StatusCode;
		this.Message=Message;
	}
	public String getStatusCode() {
		return StatusCode;
	}
	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	
	
	
	
	
}
